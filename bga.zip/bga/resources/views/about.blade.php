@extends('layout.master')
@section('content')
    <div class="title m-b-md">
        About
    </div>


@endsection

@section('footer')
    <div class="fixed-bottom bg-light">
        <p >Keep the change</p>
    </div>
@endsection
