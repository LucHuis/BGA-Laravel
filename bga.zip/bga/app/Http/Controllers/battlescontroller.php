<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class battlescontroller extends Controller
{
    //
}
